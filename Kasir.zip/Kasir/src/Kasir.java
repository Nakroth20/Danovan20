import java.util.*;

public class Kasir {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("==============Selamat Berbelanja==============");
        System.out.println("==============================");

        HashMap<String, Integer> daftarBarang = new HashMap<>();
        daftarBarang.put("Kemeja", 100000);
        daftarBarang.put("Celana", 80000);
        daftarBarang.put("Sepatu", 250000);
        daftarBarang.put("Kaos oblong", 70000);
        daftarBarang.put("Kaos kaki", 25000);
        daftarBarang.put("Kaos polo", 150000);
        daftarBarang.put("Jeans", 270000);
        daftarBarang.put("Topi", 50000);


        System.out.println("Daftar Barang: ");
        for (String barang : daftarBarang.keySet()) {
            System.out.println(barang + " = Rp" + daftarBarang.get(barang));
        }

        System.out.println("Masukkan daftar barang yang akan dibeli :");
        String inputBarang = scanner.nextLine();
        String[] daftarBelanja = inputBarang.split(",");

        int totalHarga = 0;
        for (String belanja : daftarBelanja) {
            String barangTrimmed = belanja.trim();
            if (daftarBarang.containsKey(barangTrimmed)) {
                totalHarga += daftarBarang.get(barangTrimmed);
            } else {
                System.out.println("Barang " + barangTrimmed + " tidak ada dalam daftar.");
            }
        }


        System.out.println("Masukkan kode promo (jika ada):");
        String kodePromo = scanner.nextLine();


        int diskon = 0;
        if (kodePromo.equalsIgnoreCase("PROMO20")) {
            diskon = (int) (totalHarga * 0.2); // Diskon 20%
        } else if (kodePromo.equalsIgnoreCase("PROMO50")) {
            diskon = (int) (totalHarga * 0.5); // Diskon 50%
        } else if (!kodePromo.isEmpty()) {
            System.out.println("Kode promo " + kodePromo + " tidak valid atau telah berakhir.");
        }


        int totalSetelahDiskon = totalHarga - diskon;


        System.out.println("Total Harga: Rp" + totalHarga);
        System.out.println("Diskon: Rp" + diskon);
        System.out.println("Total setelah Diskon: Rp" + totalSetelahDiskon);


        System.out.println("Masukkan jumlah uang yang dibayarkan:");
        int pembayaran = scanner.nextInt();


        int kembalian = pembayaran - totalSetelahDiskon;
        if (kembalian >= 0) {
            System.out.println("Kembalian: Rp" + kembalian);
            System.out.println("Terima kasih telah berbelanja!");
            System.out.println("Sampai jumpa di lain hari!");
        } else {
            System.out.println("Uang pembayaran tidak cukup!");
        }

        scanner.close();
    }
}
